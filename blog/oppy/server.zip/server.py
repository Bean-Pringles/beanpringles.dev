#!/usr/bin/env python3
"""
Webcam MJPEG Streaming Server
Captures video from a webcam and streams it over HTTP (MJPEG format).
Access the stream at: http://<your-ip>:<port>/
"""

import cv2
import socket
import threading
import argparse
from flask import Flask, Response, render_template_string

# ── HTML page served at the root URL ─────────────────────────────────────────
HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Webcam Stream</title>
    <style>
        body { margin: 0; background: #111; display: flex;
               flex-direction: column; align-items: center;
               justify-content: center; height: 100vh; color: #eee;
               font-family: sans-serif; }
        h2   { margin-bottom: 12px; }
        img  { max-width: 95vw; border: 2px solid #444; border-radius: 6px; }
    </style>
</head>
<body>
    <img src="/video_feed" alt="stream">
</body>
</html>
"""

app = Flask(__name__)

# ── Camera wrapper (thread-safe) ──────────────────────────────────────────────
class Camera:
    def __init__(self, src: int, width: int, height: int, fps: int):
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera index {src}")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS,          fps)
        self._lock  = threading.Lock()
        self._frame = None
        self._stop  = threading.Event()
        threading.Thread(target=self._capture_loop, daemon=True).start()

    def _capture_loop(self):
        while not self._stop.is_set():
            ok, frame = self.cap.read()
            if ok:
                with self._lock:
                    self._frame = frame

    def get_frame(self):
        with self._lock:
            return self._frame.copy() if self._frame is not None else None

    def release(self):
        self._stop.set()
        self.cap.release()


camera: Camera | None = None   # set in main()


# ── MJPEG generator ───────────────────────────────────────────────────────────
def generate_frames(quality: int = 80):
    encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
    while True:
        frame = camera.get_frame()
        if frame is None:
            continue
        ok, buffer = cv2.imencode(".jpg", frame, encode_params)
        if not ok:
            continue
        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n"
            + buffer.tobytes()
            + b"\r\n"
        )


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template_string(HTML)


@app.route("/video_feed")
def video_feed():
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )


# ── Helpers ───────────────────────────────────────────────────────────────────
def get_local_ip() -> str:
    """Return the machine's LAN IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    global camera

    parser = argparse.ArgumentParser(description="Stream webcam over HTTP (MJPEG).")
    parser.add_argument("--camera",  type=int, default=1,    help="Camera device index (default: 0)")
    parser.add_argument("--port",    type=int, default=5000, help="HTTP port (default: 5000)")
    parser.add_argument("--width",   type=int, default=1280, help="Frame width  (default: 1280)")
    parser.add_argument("--height",  type=int, default=720,  help="Frame height (default: 720)")
    parser.add_argument("--fps",     type=int, default=30,   help="Camera FPS   (default: 30)")
    parser.add_argument("--quality", type=int, default=80,   help="JPEG quality 1-100 (default: 80)")
    args = parser.parse_args()

    camera = Camera(args.camera, args.width, args.height, args.fps)

    local_ip = get_local_ip()
    print(f"\nWebcam stream running!")
    print(f"   Local  → http://127.0.0.1:{args.port}/")
    print(f"   Network→ http://{local_ip}:{args.port}/")
    print(f"   Press Ctrl+C to stop.\n")

    try:
        app.run(host="0.0.0.0", port=args.port, threaded=True)
    finally:
        camera.release()


if __name__ == "__main__":
    main()