#!/usr/bin/env python3
"""
Webcam MJPEG Streaming Server
Captures video from a webcam and streams it over HTTP (MJPEG format).
Access the stream at: http://<your-ip>:<port>/
"""

import cv2
import socket
import threading
import argparse
import subprocess
import re
import numpy as np
from flask import Flask, Response, render_template_string

HTML = """
<!DOCTYPE html>
<html>
<head>
    <title>Webcam Stream</title>
    <style>
        body { margin: 0; background: #111; display: flex;
               flex-direction: column; align-items: center;
               justify-content: center; height: 100vh; color: #eee;
               font-family: sans-serif; }
        img  { max-width: 95vw; border: 2px solid #444; border-radius: 6px; }
    </style>
</head>
<body>
    <img src="/video_feed" alt="stream">
</body>
</html>
"""

app = Flask(__name__)


# ── Camera device auto-detection ──────────────────────────────────────────────
def find_camera_device(name_hint: str) -> int | None:
    """
    Run v4l2-ctl --list-devices and return the first /dev/videoX index
    whose parent device label contains name_hint (case-insensitive).
    """
    try:
        out = subprocess.check_output(
            ["v4l2-ctl", "--list-devices"],
            stderr=subprocess.DEVNULL,
            text=True,
        )
    except FileNotFoundError:
        print("   v4l2-ctl not found — install with: sudo apt install v4l-utils")
        return None

    current_label = ""
    for line in out.splitlines():
        if not line.startswith("\t"):
            current_label = line.lower()
        else:
            match = re.search(r"/dev/video(\d+)", line)
            if match and name_hint.lower() in current_label:
                return int(match.group(1))
    return None


def resolve_camera_index(cam_arg: str) -> int | None:
    """
    Resolve the --camera argument to an integer V4L2 index.
    Accepts:
      - /dev/videoX  → extracts X
      - a plain integer string → uses it directly
      - anything else → treated as a name hint for v4l2-ctl
    Falls back to auto-detecting by 'webcam' or 'usb' if name lookup fails.
    """
    if re.fullmatch(r"/dev/video\d+", cam_arg):
        return int(cam_arg.replace("/dev/video", ""))

    if cam_arg.isdigit():
        return int(cam_arg)

    # Treat as a name hint
    index = find_camera_device(cam_arg)
    if index is not None:
        return index

    # Generic fallbacks
    print(f"   No device matching '{cam_arg}' found, trying generic hints…")
    return find_camera_device("webcam") or find_camera_device("usb")


# ── Camera wrapper (thread-safe) ──────────────────────────────────────────────
class Camera:
    def __init__(self, src: int, width: int, height: int, fps: int):
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera index {src}")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS,          fps)
        self._lock  = threading.Lock()
        self._frame = None
        self._stop  = threading.Event()
        threading.Thread(target=self._capture_loop, daemon=True).start()

    def _capture_loop(self):
        while not self._stop.is_set():
            ok, frame = self.cap.read()
            if ok:
                with self._lock:
                    self._frame = frame

    def get_frame(self):
        with self._lock:
            return self._frame.copy() if self._frame is not None else None

    def release(self):
        self._stop.set()
        self.cap.release()


camera: Camera | None = None
no_camera_frame: bytes | None = None


# ── Placeholder frame ─────────────────────────────────────────────────────────
def make_no_camera_frame(width: int = 1280, height: int = 720) -> bytes:
    """Generate a static 'No Camera' placeholder JPEG."""
    img = np.zeros((height, width, 3), dtype=np.uint8)
    img[:] = (30, 30, 30)

    label     = "NO CAMERA CONNECTED"
    sub_label = "Check device and restart server"
    font      = cv2.FONT_HERSHEY_SIMPLEX

    (tw, th), _ = cv2.getTextSize(label, font, 1.4, 2)
    cx = (width  - tw) // 2
    cy = (height + th) // 2 - 20
    cv2.putText(img, label,     (cx,  cy),      font, 1.4, (60, 60, 200), 2, cv2.LINE_AA)

    (tw2, _), _ = cv2.getTextSize(sub_label, font, 0.7, 1)
    cx2 = (width - tw2) // 2
    cv2.putText(img, sub_label, (cx2, cy + 50), font, 0.7, (140, 140, 140), 1, cv2.LINE_AA)

    _, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 80])
    return buf.tobytes()


# ── MJPEG generator ───────────────────────────────────────────────────────────
def generate_frames(quality: int = 80):
    import time
    encode_params = [cv2.IMWRITE_JPEG_QUALITY, quality]
    while True:
        if camera is None:
            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n\r\n"
                + no_camera_frame
                + b"\r\n"
            )
            time.sleep(1)
            continue

        frame = camera.get_frame()
        if frame is None:
            continue
        ok, buffer = cv2.imencode(".jpg", frame, encode_params)
        if not ok:
            continue
        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n"
            + buffer.tobytes()
            + b"\r\n"
        )


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template_string(HTML)


@app.route("/video_feed")
def video_feed():
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame",
    )


# ── Helpers ───────────────────────────────────────────────────────────────────
def get_local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


# ── Entry point ───────────────────────────────────────────────────────────────
def main():
    global camera, no_camera_frame

    parser = argparse.ArgumentParser(description="Stream webcam over HTTP (MJPEG).")
    parser.add_argument("--camera",  type=str, default="webcam",
                        help="Camera device path, index, or name hint (default: 'webcam')")
    parser.add_argument("--port",    type=int, default=5000,  help="HTTP port (default: 5000)")
    parser.add_argument("--width",   type=int, default=1280,  help="Frame width  (default: 1280)")
    parser.add_argument("--height",  type=int, default=720,   help="Frame height (default: 720)")
    parser.add_argument("--fps",     type=int, default=30,    help="Camera FPS   (default: 30)")
    parser.add_argument("--quality", type=int, default=80,    help="JPEG quality 1-100 (default: 80)")
    args = parser.parse_args()

    no_camera_frame = make_no_camera_frame(args.width, args.height)

    index = resolve_camera_index(args.camera)

    try:
        if index is None:
            raise RuntimeError("No suitable camera device found")
        camera = Camera(index, args.width, args.height, args.fps)
        print(f"   Camera opened → /dev/video{index}")
    except RuntimeError as e:
        print(f"\n⚠️  WARNING: {e}")
        print("   Server will start, but the stream will show a placeholder.\n")
        camera = None

    local_ip = get_local_ip()
    print(f"\nWebcam stream running!")
    print(f"   Local   → http://127.0.0.1:{args.port}/")
    print(f"   Network → http://{local_ip}:{args.port}/")
    print(f"   Camera  → {'✓ /dev/video' + str(index) if camera else '✗ not connected'}")
    print(f"   Press Ctrl+C to stop.\n")

    try:
        app.run(host="0.0.0.0", port=args.port, threaded=True)
    finally:
        if camera:
            camera.release()


if __name__ == "__main__":
    main()